<?php

define("MYSQL_HOST","localhost");
define("MYSQL_USER","fishbanksgame");
define("MYSQL_PASSWORD","fishbanksgame");
define("MYSQL_DB","fishbanksdb");

/**
*	Este servicio crea una conexion con la base de datos para le juego fishbanks y permite 
*   todos los datos necesarios para trabajar con esta
*/

class DatabaseConexionFishBanks {
	private $conexion;
	private $resultado;
	
	/**
	 * Hace la conexion con la bd
	 */
	function __construct(){
		global $conexion;
		$conexion = new  mysqli(MYSQL_HOST, MYSQL_USER, MYSQL_PASSWORD,MYSQL_DB);
		if ($conexion->connect_error) {
			die('Connect Error (' . mysqli_connect_errno() . ') ' . mysqli_connect_error());
		}
	}
	
	/**
	 * deberia cerrarse siempre
	 */
	function cerrarResultado(){
		global $resultado;
		$resultado->free();
	}
	
	/**
	 * cierra la conexion con la bd
	 */
	function cerrarConexion(){
		global $conexion;
		$conexion->close();
	}
	
	/**
	* Verifica los datos de registro del jugador en la base de datos
	*/
	function login($compania,$password,$juego){
		global $conexion;
		global $resultado;
		$consulta = "SELECT * 
					FROM compania 
					WHERE NOMBRE = '" . $compania . "' AND JUEGO_ID = " . $juego . " AND PASSWORD = '" . $password . "'";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function seleccionarCompanias($juego){
		global $conexion;
		global $resultado;
		$consulta = "SELECT `compania`.`NOMBRE` AS COMPANIA
					FROM `compania` 
					WHERE JUEGO_ID = " .$juego. ";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function iniciarGolfo($juego){
		global $conexion;
		global $resultado;
		$consulta = "SELECT `compania`.`NOMBRE` AS COMPANIA, `compania`.`UBICACION_TERRESTRE` AS UBICACION_COMPANIA, `barcosxcompania`.`CANTIDAD_BARCOS` AS BARCOS, `ubicacion`.`NOMBRE` AS UBICACION, `tipo_barco`.`NOMBRE` AS TIPO_BARCO 
					FROM `tipo_barco`, `compania`, `barcosxcompania`, `ubicacion` 
					WHERE ((`ubicacion`.`UBICACION_ID`  = `barcosxcompania`.`UBICACION_ID`) AND (`barcosxcompania`.`JUEGO_ID` = `compania`.`JUEGO_ID`) AND (`barcosxcompania`.`COMPANIA_NOMBRE` = `compania`.`NOMBRE`) AND (`compania`.`JUEGO_ID` = " . $juego . ") AND (`tipo_barco`.`TIPO_BARCO_ID` = `barcosxcompania`.`TIPO_BARCO_ID`)) 
					ORDER BY `compania`.`NOMBRE` ASC, `ubicacion`.`UBICACION_ID` ASC, `ubicacion`.`NOMBRE` ASC";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function balanceCompanias($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT `reporte`.`COMPANIA_NOMBRE`, SUM(`reporte`.`BALANCE_GENERAL`) AS ESTADO_RESULTADOS, `compania`.`UBICACION_TERRESTRE`
					FROM reporte, `compania`
					WHERE ((`reporte`.`JUEGO_ID` = " . $juego . ") AND (`compania`.`NOMBRE` =  `reporte`.`COMPANIA_NOMBRE`)) AND (`compania`.`JUEGO_ID` = `reporte`.`JUEGO_ID`)
					GROUP BY `reporte`.`COMPANIA_NOMBRE`";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function desicionDeLaCompania($juego, $compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * 
					FROM DECISION
					WHERE COMPANIA_NOMBRE = '" . $compania . "' AND JUEGO_ID = " . $juego . " AND TURNO_ID = (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . "));";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function barcosPorCompania($juego, $compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * 
					FROM `BARCOSXCOMPANIA`
					WHERE `BARCOSXCOMPANIA`.`COMPANIA_NOMBRE` = '" . $compania . "' AND `BARCOSXCOMPANIA`.`JUEGO_ID` = " . $juego . ";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function estadoActualDeBarcos($juego, $compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT `tipo_barco`.`NOMBRE` AS NOMBRE_BARCO, `tipo_barco`.`PRECIO` AS PRECIO_BARCO, `tipo_barco`.`CAPACIDAD` AS CAPACIDAD_BARCO, `ubicacion`.`NOMBRE` AS UBICACION, `barcosxcompania`.`CANTIDAD_BARCOS` AS BARCOS_EN_UBICACION 
					FROM `barcosxcompania`, `tipo_barco`, `ubicacion`
					WHERE ((`barcosxcompania`.`JUEGO_ID` = " . $juego . ") AND (`barcosxcompania`.`COMPANIA_NOMBRE` = '" . $compania . "') AND (`barcosxcompania`.`TIPO_BARCO_ID` = `tipo_barco`.`TIPO_BARCO_ID`) AND (`barcosxcompania`.`UBICACION_ID` = `ubicacion`.`UBICACION_ID`))";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function subastaActiva($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT *
				FROM SUBASTA
				WHERE JUEGO_ID = " . $juego . " AND TURNO_ID = (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . "));";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function iniciarTemporizador($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT *, CURRENT_TIMESTAMP
					FROM `juego`
					WHERE `juego`.`JUEGO_ID` = " . $juego . ";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function mensajeAlentador($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT TEXTO 
					FROM MENSAJE
					WHERE JUEGO_ID = " . $juego . " AND TURNO_ID = (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . "));";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function tiposBarco() {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * FROM `tipo_barco`;";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function tiposPez() {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * FROM `tipo_pez`;";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function obtenerJuegos() {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * FROM `juego`;";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function calcularCostosOperativos($juego, $compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT CALCULAR_COSTOS_OPERATIVOS(".$juego.",'".$compania."') AS COSTOS_OPERATIVOS;";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function verificarPedido($juego,$compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * 
					FROM PEDIDO
					WHERE COMPANIA_NOMBRE = '" . $compania . "' AND JUEGO_ID = " . $juego . " AND TURNO_ID = (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . "));";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function turnoActual($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . ") AND TURNO_ID = (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . ")) ;";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function obtenerPoblacion($juego) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * FROM `pez` WHERE `juego_id` =  " . $juego . ";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
	function hacerPedidos($juego,$compania,$num_chalupas,$num_pangas,$num_pesqueros) {
		global $conexion;
		global $resultado;
		$consulta = "INSERT INTO PEDIDO 
					VALUES ('".$compania."',".$juego.", (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . ")), ".$num_chalupas.", ".$num_pangas.", ".$num_pesqueros.")
					ON DUPLICATE KEY UPDATE
					NUMERO_CHALUPAS = ".$num_chalupas." , NUMERO_PANGAS = ".$num_pangas." , NUMERO_BARCO_PESQUERO = ".$num_pesqueros.";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado;
		}
		return false;
	}
	
	function hacerOferta($juego,$compania,$oferta) {
		global $conexion;
		global $resultado;
		$consulta = "INSERT INTO OFERTA VALUES(".$oferta.",'".$compania."' , ".$juego.", (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . ")))
					ON DUPLICATE KEY UPDATE 
					VALOR = ".$oferta.";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado;
		}
		return false;
	}

	function posicionarBarcos($juego,$compania,$num_chalupas_costa,$num_chalupas_mar_profundo,$num_chalupas_puerto,$num_pangas_costa,$num_pangas_mar_profundo,$num_pangas_puerto,$num_pesqueros_costa,$num_pesqueros_mar_profundo,$num_pesqueros_puerto) {
		global $conexion;
		global $resultado;
		$consulta = "INSERT INTO DECISION 
					VALUES ('" . $compania . "', " . $juego . ", (SELECT MAX(`turno`.`TURNO_ID`) FROM `turno` WHERE (`turno`.`JUEGO_ID` = " . $juego . ")), " . $num_chalupas_costa . ", " . $num_chalupas_mar_profundo . ", " . $num_chalupas_puerto . ", " . $num_pangas_costa . ", " . $num_pangas_mar_profundo . ", " . $num_pangas_puerto . ", " . $num_pesqueros_costa . ", " . $num_pesqueros_puerto . ", " . $num_pesqueros_mar_profundo . ")
					ON DUPLICATE KEY UPDATE 
					CHALUPAS_COSTA = " . $num_chalupas_costa . " , 
					CHALUPAS_MAR_PROFUNDO = " . $num_chalupas_mar_profundo . " ,
					CHALUPAS_PUERTO = " . $num_chalupas_puerto . " , 
					PANGA_COSTA = " . $num_pangas_costa . " , 
					PANGA_MAR_PROFUNDO = " . $num_pangas_mar_profundo . " , 
					PANGA_PUERTO = " . $num_pangas_puerto . " , 
					BARCO_PESQUERO_COSTA = " . $num_pesqueros_costa . " , 
					BARCO_PESQUERO_PUERTO = " . $num_pesqueros_puerto . " , 
					BARCO_PESQUERO_MAR_PROFUNDO = " . $num_pesqueros_mar_profundo . ";";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado;
		}
		return false;
	}
	
	function obtenerDatosEstadisticas($juego,$compania) {
		global $conexion;
		global $resultado;
		$consulta = "SELECT * 
					FROM REPORTE
					WHERE JUEGO_ID = " . $juego . " AND COMPANIA_NOMBRE = '" . $compania . "';";
		$resultado = $conexion->query($consulta);
		if($resultado != false) {
			return $resultado->fetch_all(MYSQLI_ASSOC);
		}
		return false;
	}
	
}
?>